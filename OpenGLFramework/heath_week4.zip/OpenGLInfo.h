#ifndef OPENGLINFO
#define OPENGLINFO

struct OpenGLInfo
{
	unsigned int m_VAO;
	unsigned int m_VBO;
	unsigned int m_faceCount;
};

#endif