#ifndef OBJVERTEX
#define OBJVERTEX

struct OBJVertex
{
	float x, y, z;
	float nx, ny, nz;
	float u, v;
};

#endif
